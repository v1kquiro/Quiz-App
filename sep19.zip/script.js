const questionContainer = document.querySelector('question-container');
const questionElement = document.querySelector('question');
const answerInput = document.querySelector('.answer');
const choices = document.querySelector('.choices');
const nextBtn = document.querySelector('.nextBtn');
const timerDisplay = document.querySelector('.timer');
const timeElapsed = document.querySelector('time-elapsed');
const submitBtn = document.querySelector('submit-btn');
const resultDisplay = document.querySelector('.result');

let shuffledQuestions, currentQuestionIndex, score;

const question = {
    1: {
        question: "What is the capital of France?", 
        answer: [
            {text: "France", correct: true},
            {text: "Texas", correct: false},
            {text: "China", correct: false},
            {text: "Netherlands", correct: false},
        ],

        question: "What is 2 + 2?",
         answer: [
            {text: "4", correct: true},
            {text: "21", correct: false},
            {text: "69", correct: false},
            {text: "124", correct: false},
         ],

        question: "What is the capital of Spain?",
         answer: [
            {text: "Madrid", correct: true},
            {text: "France", correct: false},
            {text: "Belgium", correct: false},
            {text: "California", correct: false},
         ]
        },

    2: {
        question: "What is the largest planet?",
        answer: [
            {text:"Jupiter", correct: true},
            {text:"Saturn", correct: false},
            {text:"Mars", correct: false},
            {text:"Earth", correct: false},
        ],

        question: "What is the capital of Italy?", 
        answer: [
            {text: "Rome", correct: true},
            {text: "France", correct: false},
            {text: "China", correct: false},
            {text: "Japan", correct: false},
        ],

        question: "Who wrote 'Romeo and Juliet'?",
        answer: [
            {text: "Shakespeare", correct: true},
            {text: "Ghandi", correct: false},
            {text: "Obama", correct: false},
            {text: "Mr. Ellis", correct: false},
        ],
    },

    3: {
        question: "What is the atomic number of Hydrogen?", 
        answer: [
            {text: "1", correct: true},
            {text: "5", correct: false},
            {text: "21", correct: false},
            {text: "10000", correct: false},
        ],

        question: "What is the boiling point of water?",
        answer: [
            {text: "100", correct: true},
            {text: "1", correct: false},
            {text: "80000", correct: false},
            {text: "0.07", correct: false},
        ],

        question: "What element has the symbol 'O'?",
        answer: [
            {text: "Oxygen", correct: true},
            {text: "Hyrdrogen", correct: true},
            {text: "Lithium", correct: true},
            {text: "Oganesson", correct: true},
        ]
    }
};


let currentQuestion;
let interval;
let quizId = new URLSearchParams(window.location.search).get('quiz'); //will discuss in class
let questions = [],
    time = 30;
    score = 0;

    function buidlQuiz(){}

    function showResults(){

        const answerContainers = quizContainer.querySelectorAll('.answers');

        let numCorrect = 0;

        myQuestions.forEach( (currentQuestion, questionNumber) => {

            const answerContainer = answerContainers[questionNumber];
            const selector = 'input[name=question${questionNumber}]:checked';
            const userAnswer = (answerContainer.querySelector(selector)) || {}.value;

            if(userAnswer === currentQuestion.correctAnswer){
                numCorrect++;

                answerContainers[questionNumber].style.color = 'lightgreen';
            } else {
                answerContainers[questionNumber].style.color = 'red';
            }
        });
        resultContainer.innerHTML = '${numCorrect} out of ${myQuestions.lenght}';
    }

// Event listener for when the user clicks the "Submit Answer" button,will discuss in class
submitButton.addEventListener('click', showResults);

// Event listener for when the page finishes loading, starting the quiz, will discuss in class
document.addEventListener("DOMContentLoaded", startQuiz);

function startQuiz() {
   currentQuestionIndex = 0;
   score = 0;
   time = 30;
   startTimer();
   displayNextQuestion();
}

function displayNextQuestion() {
    if (curentQuestionIndex < question.length) {
        const currentQuestion = questions[currentQuestionIndex];
        questionElement.textContent = currentQuestion.question;
        answerInput.value = '';
    } else{
        endQuiz();
    }
}

function checkAnswer() {
    const userAnswer = anwswerInput.value.trim();
    const correctAnswer = questions[currentQuestionIndex].answer;

    if (userAnswer.toLowerCase() === correctAnswer.toLowerCase()){
        score++;
        currentQuestionIndex++;
        displayNextQuestion();
    } else {
        alert("Nah bro you wrong!!");
    }
}

function startTimer() {
    interval = setInterval(updateTimer, 1000);
}

function updateTimer() {
    if (time > 0) {
        time--;
        timerDisplay.textContent = 'Time: ${time}s';
    } else {
        endQuiz();
    }
}

function endQuiz() {
    clearInterval(interval);
    questionElement.textContent = '';
    answerInput.value = '';
    timerDisplay.textContent = '';
    resultDisplay.textContent = 'Quiz Completed! Your score: ${score} out of ${questions.length}';
    resultDisplay.style.display = 'block';
    container.style.display = 'none';

}

window.onload = startQuiz;
