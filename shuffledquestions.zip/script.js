document.addEventListener("DOMContentLoaded", function() {
    const submitButton = document.getElementById('submit-btn');
    const questionElement = document.querySelector('.question-text');
    const optionList = document.querySelector('.option-list');
    const timerDisplay = document.querySelector('.timer');
    const resultDisplay = document.querySelector('.result');
    const scoreDisplay = document.getElementById('score-display'); // Added to display score dynamically
    let currentQuestionIndex = 0;
    let score = 0;
    let time = 30;
    let interval;



    let questions = [
        {
            question: "What is the capital of France?",
            answers: [
                {text: "Paris", correct: true},
                {text: "Austin", correct: false},
                {text: "Shanghai", correct: false},
                {text: "Amsterdam", correct: false},
            ]
        },
        {
            question: "What is 2 + 2?",
            answers: [
                { text: "4", correct: true },
                { text: "21", correct: false },
                { text: "69", correct: false },
                { text: "124", correct: false }
            ]
        },
        {
            question: "What is the capital of Spain?",
            answers: [
             { text: "Madrid", correct: true },
             { text: "Bangkok", correct: false },
             { text: "Brussels", correct: false },
             { text: "Lima", correct: false },
         ]
        },
        {
            question: "What is the largest planet?",
            answers: [
                {text:"Jupiter", correct: true},
                {text:"Saturn", correct: false},
                {text:"Mars", correct: false},
                {text:"Earth", correct: false},
            ],
    
            question: "What is the capital of Italy?", 
            answers: [
                {text: "Rome", correct: true},
                {text: "New York", correct: false},
                {text: "Venice", correct: false},
                {text: "Vietnam", correct: false},
            ],
    
            question: "Who wrote 'Romeo and Juliet?",
            answers: [
                {text: "Shakespeare", correct: true},
                {text: "Ghandhi", correct: false},
                {text: "Obama", correct: false},
                {text: "Mr. Ellis", correct: false},
            ],
        },
     {
            question: "What is the atomic number of Hydrogen?", 
            answers: [
                {text: "1", correct: true},
                {text: "5", correct: false},
                {text: "21", correct: false},
                {text: "10000", correct: false},
            ],
    
            question: "What is the boiling point of water?",
            answers: [
                {text: "100", correct: true},
                {text: "1", correct: false},
                {text: "80000", correct: false},
                {text: "0.07", correct: false},
            ],
    
            question: "What element has the symbol 'O'?",
            answers: [
                {text: "Oxygen", correct: true},
                {text: "Hyrdrogen", correct: true},
                {text: "Lithium", correct: true},
                {text: "Oganesson", correct: true},
            ]
        },
        // Add more questions here
    ];

    if (submitButton) {
        submitButton.addEventListener('click', showResults);
    }

    function displayNextQuestion() {
        const currentQuestion = questions[currentQuestionIndex];

        if (questionElement) {
            questionElement.textContent = currentQuestion.question;
        }

        optionList.innerHTML = '';

        currentQuestion.answers.forEach(answer => {
            const button = document.createElement('button');
            button.innerText = answer.text;
            button.classList.add('option');
            button.dataset.correct = answer.correct; // Set data-correct attribute
            button.addEventListener('click', selectAnswer);
            optionList.appendChild(button);
        });
    }

    function selectAnswer(e) {
        const selectedButton = e.target;
        const isCorrect = selectedButton.dataset.correct === 'true';

        if (isCorrect) {
            score++; // Increment score if the answer is correct
            updateScoreDisplay(); // Update the score in the DOM
        }

        currentQuestionIndex++;

        if (currentQuestionIndex < questions.length) {
            displayNextQuestion(); // Load the next question
        } else {
            endQuiz(); // End quiz if no more questions
        }
    }

    function updateScoreDisplay() {
        // Update the score on the page in real-time
        if (scoreDisplay) {
            scoreDisplay.textContent = score;
        }
    }

    function showResults() {
        currentQuestionIndex++;

        if (currentQuestionIndex < questions.length) {
            displayNextQuestion();
        } else {
            endQuiz();
        }
    }

    function startQuiz() {
        currentQuestionIndex = 0;
        score = 0;
        updateScoreDisplay(); // Initialize score display
        startTimer();
        displayNextQuestion();
    }

    function startTimer() {
        interval = setInterval(updateTimer, 1000);
    }

    function updateTimer() {
        if (time > 0) {
            time--;
            if (timerDisplay) {
                timerDisplay.textContent = `Time: ${time}s`;
            }
        } else {
            endQuiz();
        }
    }

    function endQuiz() {
        clearInterval(interval);

        if (questionElement) {
            questionElement.textContent = '';
        }

        if (resultDisplay) {
            resultDisplay.textContent = `Quiz Completed! Your final score is ${score} out of ${questions.length}.`;
        }

        if (optionList) {
            optionList.innerHTML = '';
        }

        if (submitButton) {
            submitButton.style.display = 'none';
        }
    }

    startQuiz();
});
