const quizzes = {
    1: [
        { question: "What is the capital of France?", answer: "Paris" },
        { question: "What is 2 + 2?", answer: "4" },
        { question: "What is the capital of Spain?", answer: "Madrid" }
    ],
    2: [
        { question: "What is the largest planet?", answer: "Jupiter" },
        { question: "What is the capital of Italy?", answer: "Rome" },
        { question: "Who wrote 'Romeo and Juliet'?", answer: "Shakespeare" }
    ],
    3: [
        { question: "What is the atomic number of Hydrogen?", answer: "1" },
        { question: "What is the boiling point of water?", answer: "100" },
        { question: "What element has the symbol 'O'?", answer: "Oxygen" }
    ]
};

const container = document.querySelector('.container');
const question = document.querySelector('.question');
const answerInput = document.querySelector('.answer');
const choices = document.querySelector('.choices');
const nextBtn = document.querySelector('.nextBtn');
const timerDisplay = document.querySelector('.timer');
const submitBtn = document.querySelector('submit-btn');
const resultDisplay = document.querySelector('.result');


let currentQuestionIndex = 0;
let interval;
let quizId = new URLSearchParams(window.location.search).get('quiz'); //will discuss in class
let questions = [],
    time = 30,
    score = 0,


// Event listener for when the user clicks the "Submit Answer" button,will discuss in class
document.getElementById("submitBtn").addEventListener("click", checkAnswer);

// Event listener for when the page finishes loading, starting the quiz, will discuss in class
document.addEventListener("DOMContentLoaded", startQuiz);

function startQuiz() {
   currentQuestionIndex = 0;
   score = 0;
   time = 30;
   startTimer();
   displayNextQuestion();
}

function displayNextQuestion() {
    if (curentQuestionIndex < question.length) {
        const currentQuestion = questions[currentQuestionIndex];
        questionElement.textContent = currentQuestion.question;
        answerInput.value = '';
    } else{
        endQuiz();
    }
}

function checkAnswer() {
    const userAnswer = anwswerInput.value.trim();
    const correctAnswer = questions[currentQuestionIndex].answer;

    if (userAnswer.toLowerCase() === correctAnswer.toLowerCase()){
        score++;
        currentQuestionIndex++;
        displayNextQuestion();
    } else {
        alert("Nah bro you wrong!!");
    }
}

function startTimer() {
    interval = setInterval(updateTimer, 1000);
}

function updateTimer() {
    if (time > 0) {
        time--;
        timerDisplay.textContent = 'Time: ${time}s';
    } else {
        endQuiz();
    }
}

function endQuiz() {
    clearInterval(interval);
    questionElement.textContent = '';
    answerInput.value = '';
    timerDisplay.textContent = '';
    resultDisplay.textContent = 'Quiz Completed! Your score: ${score} out of ${questions.length}';
    resultDisplay.style.display = 'block';
    container.style.display = 'none';

}
