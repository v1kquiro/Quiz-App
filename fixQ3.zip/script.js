document.addEventListener("DOMContentLoaded", function() {
    const submitButton = document.getElementById('submit-btn');
    const questionElement = document.querySelector('.question-text');
    const optionList = document.querySelector('.option-list');
    const timerDisplay = document.querySelector('.timer');
    const resultDisplay = document.querySelector('.result');
    const scoreDisplay = document.getElementById('score-display'); // Added to display score dynamically
    let currentQuestionIndex = 0;
    let score = 0;
    let time = 30;
    let interval;

    let questions = [
        {
            question: "What is the capital of France?",
            answers: [
                {text: "Paris", correct: true},
                {text: "Austin", correct: false},
                {text: "Shanghai", correct: false},
                {text: "Amsterdam", correct: false},
            ]
        },
        {
            question: "What is 2 + 2?",
            answers: [
                { text: "4", correct: true },
                { text: "21", correct: false },
                { text: "69", correct: false },
                { text: "124", correct: false }
            ]
        },
        {
            question: "What is the capital of Spain?",
         answer: [
            {text: "Madrid", correct: true},
            {text: "Bangkok", correct: false},
            {text: "Brussels", correct: false},
            {text: "Lima", correct: false},
         ]
        }
        // Add more questions here
    ];

    if (submitButton) {
        submitButton.addEventListener('click', showResults);
    }

    function displayNextQuestion() {
        const currentQuestion = questions[currentQuestionIndex];

        if (questionElement) {
            questionElement.textContent = currentQuestion.question;
        }

        optionList.innerHTML = '';

        currentQuestion.answers.forEach(answer => {
            const button = document.createElement('button');
            button.innerText = answer.text;
            button.classList.add('option');
            button.dataset.correct = answer.correct; // Set data-correct attribute
            button.addEventListener('click', selectAnswer);
            optionList.appendChild(button);
        });
    }

    function selectAnswer(e) {
        const selectedButton = e.target;
        const isCorrect = selectedButton.dataset.correct === 'true';

        if (isCorrect) {
            score++; // Increment score if the answer is correct
            updateScoreDisplay(); // Update the score in the DOM
        }

        currentQuestionIndex++;

        if (currentQuestionIndex < questions.length) {
            displayNextQuestion(); // Load the next question
        } else {
            endQuiz(); // End quiz if no more questions
        }
    }

    function updateScoreDisplay() {
        // Update the score on the page in real-time
        if (scoreDisplay) {
            scoreDisplay.textContent = score;
        }
    }

    function showResults() {
        currentQuestionIndex++;

        if (currentQuestionIndex < questions.length) {
            displayNextQuestion();
        } else {
            endQuiz();
        }
    }

    function startQuiz() {
        currentQuestionIndex = 0;
        score = 0;
        updateScoreDisplay(); // Initialize score display
        startTimer();
        displayNextQuestion();
    }

    function startTimer() {
        interval = setInterval(updateTimer, 1000);
    }

    function updateTimer() {
        if (time > 0) {
            time--;
            if (timerDisplay) {
                timerDisplay.textContent = `Time: ${time}s`;
            }
        } else {
            endQuiz();
        }
    }

    function endQuiz() {
        clearInterval(interval);

        if (questionElement) {
            questionElement.textContent = '';
        }

        if (resultDisplay) {
            resultDisplay.textContent = `Quiz Completed! Your final score is ${score} out of ${questions.length}.`;
        }

        if (optionList) {
            optionList.innerHTML = '';
        }

        if (submitButton) {
            submitButton.style.display = 'none';
        }
    }

    startQuiz();
});
